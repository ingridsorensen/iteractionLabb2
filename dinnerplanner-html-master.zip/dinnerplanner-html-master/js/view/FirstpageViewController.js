//ExampleViewController Object constructor
var firstpageViewController = function(view, model) {
 	view.newDinner.click(function(){
 		 	document.getElementById('id1').style.color = red;
 	});
}

